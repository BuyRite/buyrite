<div style="clear:both;"></div>

<div id="footer">

	<div class="binfo"><a href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('name'); ?>">
            <?php bloginfo('name'); ?></a> All rights reserved</div>
<p class="art-page-footer"><?php 
/* This theme is powered by free-wordpress-theme.net, please do NOT remove the comment or anything below. */
			wp_theme_GPL_credits();
/* This theme is powered by free-wordpress-theme.net, please do NOT remove the comment or anything below. */ ?></p>
</div>

<?php do_action('wp_footer'); ?>

</div>

</body>
</html>
