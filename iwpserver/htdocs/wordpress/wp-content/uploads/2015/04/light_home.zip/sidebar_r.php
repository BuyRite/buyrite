<div id="sidebar3">
	<ul>
	<li>
	<h2>Search</h2>
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<input type="text" value="Type and press Enter" name="s" id="searchside" onfocus="if (this.value == 'Type and press Enter') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Type and press Enter';}" /></form>
	</li>
<li>
	<h2> Newsletter</h2>
<form style="padding:0px;text-align:left;" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php $feedburner_feed = get_option('light_feedburner_feed'); echo $feedburner_feed; ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true"><center>Type email and press Enter:</center> <input type="text" id="searchside"  name="email"/><input type="hidden" value="<?php $feedburner_feed = get_option('light_feedburner_feed'); echo $feedburner_feed; ?>" name="uri"/><input type="hidden" name="loc" value="en_US"/></form>
</li>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	<li>
			<h2>Recent Posts</h2>
			<ul>
				<?php wp_get_archives('type=postbypost&limit=10'); ?>
			</ul> </li>
						<?php endif; ?>
		</ul>
	</div>