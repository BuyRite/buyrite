			<div class="post">
		<h5 class="center">You are looking for something that isn't here.</h5>
<h5 class="center"> Try searching again...</h5>
		<p><center><?php include(TEMPLATEPATH."/src_form.php");?> </center> <h5 class="center">or take a look at the Archives.</h5> <?php include(TEMPLATEPATH."/archives.php");?> </p>
	</div>