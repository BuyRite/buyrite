<?php
/*
Template Name: Links
*/
?>
<?php wp_get_header(); ?>
<div id="pbody">
<?php include(TEMPLATEPATH."/sidebar_l.php");?>
	<div id="content">
<div class="post">
<h2>Links:</h2>
<ul>
<?php wp_list_bookmarks(); ?>
</ul>
</div> </div>
<?php include(TEMPLATEPATH."/sidebar_r.php");?>
</div>
<?php wp_get_footer(); ?>