<?php wp_get_header(); ?>
<div id="pbody">
<?php include(TEMPLATEPATH."/sidebar_l.php");?>
	<div id="content">

	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
				<div class="ptitle"><h2>
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
				<div class="entry">
<?php the_content('Read the rest of this entry &raquo;'); ?>
</div>
				<p class="postmetadata"> <?php the_time('j M Y') ?><br><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
			</div>
		<?php endwhile; ?>
		<div class="navigation">

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
			else { ?>

			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
				<?php } ?>

		</div>
	<?php else : ?>
	    <?php include(TEMPLATEPATH."/404.php");?>
      	<?php endif; ?>
</div>
<?php include(TEMPLATEPATH."/sidebar_r.php");?>
</div>
<?php wp_get_footer(); ?>