<?php wp_get_header();?>
<div id="pbody">
<?php include(TEMPLATEPATH."/sidebar_l.php");?>
	<div id="content">			
		<?php if (have_posts()) : ?>
 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
		
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		
	  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		
 	  <?php } ?>

		<?php while (have_posts()) : the_post(); ?>
		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
				<div class="ptitle"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
				
             	<div class="entry">
                    <?php the_content('Read the rest of this entry &raquo;'); ?>
				    </div>
				<p class="postmetadata"> <?php the_time('j M Y') ?><br> <?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
</div>
		<?php endwhile; ?>
		<div class="navigation">

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
			else { ?>

			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
				<?php } ?>

		</div>

	<?php else :
		if ( is_category() ) { // If this is a category archive
			printf("<h5>Sorry, but there aren't any posts in the %s category yet.</h5>", single_cat_title('',false));
		} else if ( is_date() ) { // If this is a date archive
			echo("<h5>Sorry, but there aren't any posts with this date.</h5>
");
		} else if ( is_author() ) { // If this is a category archive
			$userdata = get_userdatabylogin(get_query_var('author_name'));
			printf("<h5>Sorry, but there aren't any posts by %s yet.</h5>", $userdata->display_name);
		} else {
			echo("<h5>No posts found.</h5>");
		}
	endif;?>
	</div>
<?php include(TEMPLATEPATH."/sidebar_r.php");?>
</div>
<?php wp_get_footer(); ?>