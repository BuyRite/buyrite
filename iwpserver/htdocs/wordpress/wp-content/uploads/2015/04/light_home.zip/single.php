<?php wp_get_header();?>
<div id="pbody">
<?php include(TEMPLATEPATH."/sidebar_l.php");?>
	<div id="content">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<div class="ptitle"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2></div>
				<div class="entry">
				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				</div><p class="postmetadata"> <?php the_time('j M Y') ?><br><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></p>
			
		</div>
<div id="replies">
	<?php comments_template(); ?>
</div>
	<?php endwhile; else: ?>
	    <?php include(TEMPLATEPATH."/404.php");?>
      <?php endif; ?>
	</div>
<?php include(TEMPLATEPATH."/sidebar_r.php");?>
</div>
<?php wp_get_footer(); ?>